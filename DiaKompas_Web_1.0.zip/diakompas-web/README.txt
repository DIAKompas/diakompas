DiaKompas CZ / SK / EN – web 1.0

Otevření:
1. Rozbalte ZIP.
2. Otevřete index.html v prohlížeči Chrome, Firefox, Edge nebo Safari.
3. Přepínejte jazyky tlačítky CZ / SK / EN.

Funkce: responzivní design, 3 jazyky, 6 témat, 3 úvodní články,
vyhledávání v článcích, odkazy na odborné zdroje, informační upozornění.

Nasazení zdarma: GitHub Pages nebo Cloudflare Pages.
Jedná se o statický web; žádný účet ani server nejsou potřeba.

DŮLEŽITÉ: Toto je pilotní demonstrace. Zdravotní texty před veřejným
zveřejněním nechte odborně posoudit kvalifikovaným zdravotníkem.
Logo je původní zjednodušená SVG adaptace schváleného grafického směru,
nikoli přesná vektorová kopie původního obrázku.
Nejsou zapojeny formuláře, databáze, analytika ani reklamy.
