DiaKompas 2.0

Nahrajte index.html do kořene GitHub repozitáře diakompas (nahraďte starý soubor).
GitHub Pages: Settings > Pages > Deploy from a branch > main > /(root).

Důležité: Zdravotnický obsah je redakční návrh. Před veřejnou propagací zajistěte kontrolu kvalifikovaným zdravotníkem.
Nedoplňujte neexistující odborné garance ani falešné kontakty.
