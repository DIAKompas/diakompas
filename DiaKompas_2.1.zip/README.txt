DiaKompas 2.1

Pro GitHub Pages nahrajte soubor index.html do kořenové složky repozitáře diakompas (větev main).
Soubory content.json a README.txt jsou doplňkové; web funguje samostatně z index.html.

Obsah: 6 článků × 3 jazyky; interaktivní filtrování a hledání; vektorové ilustrace; responzivní design.

DŮLEŽITÉ: Zdravotnické články jsou redakční návrhy a vyžadují odbornou revizi před propagací.
